package com.eteration.simplebanking.model;




import javax.persistence.*;
import java.util.Date;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "Transaction")
public abstract class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column

    public Date date;

    @Column
    public double amount;

    @Column
    public String type;



    @ManyToOne(fetch = FetchType.LAZY)
    private Account account;

    public Transaction() {

    }

    public Transaction(double transaction) {

        date = new Date();
        this.date = date;
        this.amount = transaction;

    }

    public String toString() {
        return null;

    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }


}
