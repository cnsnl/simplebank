package com.eteration.simplebanking.model;

import javax.persistence.Entity;

@Entity
public class BillPaymentTransaction extends Transaction {

    public String obligee;

    public BillPaymentTransaction() {
    }

    public BillPaymentTransaction(double a) {
        super(a);
    }

    public String getPayee() {
        return obligee;
    }

    public void setPayee(String payee) {
        this.obligee = obligee;
    }
}
