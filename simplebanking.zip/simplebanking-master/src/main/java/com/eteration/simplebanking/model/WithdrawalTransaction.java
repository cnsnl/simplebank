package com.eteration.simplebanking.model;


import javax.persistence.Entity;


@Entity
public class WithdrawalTransaction extends Transaction {

    public WithdrawalTransaction() {

    }

    public WithdrawalTransaction(double withdrawalTransaction) {
        super(withdrawalTransaction);
        this.setType("WithdrawalTransaction");
    }
}





