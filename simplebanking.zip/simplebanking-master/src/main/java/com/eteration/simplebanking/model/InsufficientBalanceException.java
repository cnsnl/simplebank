package com.eteration.simplebanking.model;



    public class InsufficientBalanceException extends Exception {
}